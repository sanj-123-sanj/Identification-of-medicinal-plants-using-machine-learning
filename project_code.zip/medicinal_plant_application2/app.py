# Importing essential libraries and modules

from flask import Flask, render_template, request, Markup
import numpy as np
import pandas as pd

import requests
import config
import pickle
import io
from PIL import Image
from reportlab.lib.pagesizes import letter
from reportlab.pdfgen import canvas

# ==============================================================================================

# -------------------------LOADING THE TRAINED MODELS -----------------------------------------------

# Loading plant disease classification model

plant_data=[

{
    "plant_name": "Aloevera",
    "medicine_content": "Aloin, polysaccharides, vitamins, minerals",
    "diseases_cured": ["Skin conditions", "Digestive problems"],
    "age_restrictions": "No age restrictions",
    "gender_restrictions": "No gender restrictions",
    "pregnant_use_restriction": "Consult a doctor during pregnancy",
    "mode_of_use": "Topical application or oral consumption",
    "doses_for_day": "2-3 times a day"
},
{
    "plant_name": "Amla",
    "medicine_content": "Vitamin C, tannins, flavonoids",
    "diseases_cured": ["Boosts immunity", "Improves digestion", "Hair health"],
    "age_restrictions": "Safe for all ages",
    "gender_restrictions": "No gender restrictions",
    "pregnant_use_restriction": "Generally safe during pregnancy, but consult a doctor",
    "mode_of_use": "Consumed raw, as a juice, or in various recipes",
    "doses_for_day": "1-2 amla fruits or 20-30 ml of amla juice per day"
},
 {
    "plant_name": "Amruthaballi",
    "medicine_content": "Alkaloids, flavonoids, glycosides",
    "diseases_cured": ["Boosts immunity", "Fever", "Respiratory disorders"],
    "age_restrictions": "Safe for all ages",
    "gender_restrictions": "No gender restrictions",
    "pregnant_use_restriction": "Consult a doctor during pregnancy",
    "mode_of_use": "Decoction, powder, or as directed by an Ayurvedic practitioner",
    "doses_for_day": "Typically 1-2 teaspoons of powder or as per practitioner's advice"
},
{
    "plant_name": "Arali",
    "medicine_content": "Alkaloids, flavonoids, tannins",
    "diseases_cured": ["Skin conditions", "Rheumatism", "Asthma"],
    "age_restrictions": "Safe for adults; consult a doctor for children",
    "gender_restrictions": "No gender restrictions",
    "pregnant_use_restriction": "Consult a doctor during pregnancy",
    "mode_of_use": "Topical application of the paste or as directed by an Ayurvedic practitioner",
    "doses_for_day": "As directed by an Ayurvedic practitioner for internal use; for external use, apply as needed"
}]





disease_dic= [
    "Aloevera",
    "Amla",
    "Amruthaballi",
    "Arali",
    "Astma_weed",
    "Badipala",
    "Balloon_Vine",
    "Bamboo",
    "Beans",
    "Betel",
    "Bhrami",
    "Bringaraja",
    "Caricature",
    "Castor",
    "Catharanthus",
    "Chakte",
    "Chilly",
    "Citron lime (herelikai)",
    "Coffee",
    "Common rue(naagdalli)",
    "Coriander",
    "Curry",
    "Doddpathre",
    "Drumstick",
    "Ekka",
    "Eucalyptus",
    "Ganigale",
    "Ganike",
    "Gasagase",
    "Ginger",
    "Globe Amaranth",
    "Guava",
    "Henna",
    "Hibiscus",
    "Honge",
    "Insulin",
    "Jackfruit",
    "Jasmine",
    "Kambajala",
    "Kasambruga",
    "Kohlrabi",
    "Lantana",
    "Lemon",
    "Lemongrass",
    "Malabar Nut",
    "Malabar Spinach",
    "Mango",
    "Marigold",
    "Mint",
    "Neem",
    "Nelavembu",
    "Nerale",
    "Nooni",
    "Onion",
    "Padri",
    "Palak (Spinach)",
    "Papaya",
    "Parijatha",
    "Pea",
    "Pepper",
    "Pomegranate",
    "Pumpkin",
    "Radish",
    "Rose",
    "Sampige",
    "Sapota",
    "Seethaashoka",
    "Seethapala",
    "Spinach1",
    "Tamarind",
    "Taro",
    "Tecoma",
    "Thumbe",
    "Tomato",
    "Tulsi",
    "Turmeric",
    "Ashoka",
    "Camphor",
    "Kamakasturi",
    "Kepala"
]

details = None

from model_predict  import pred_leaf_disease

# ===============================================================================================
# ------------------------------------ FLASK APP -------------------------------------------------


app = Flask(__name__)

# render home page


@ app.route('/')
def home():
    #title = 'Diabetic Retinopathy Detection'
    return render_template('index3.html')

# render crop recommendation form page

@ app.route('/index2')
def index2():
    #title = 'Diabetic Retinopathy Detection'
    return render_template('main_page.html')




@app.route('/disease-predict', methods=['GET', 'POST'])
def disease_prediction():
    title = 'Diabetic Retinopathy Detection'

    if request.method == 'POST':
        #if 'file' not in request.files:
         #   return redirect(request.url)

            file = request.files.get('file')

           # if not file:
            #    return render_template('disease.html', title=title)

            img = Image.open(file)
            img.save('output.png')


            prediction =pred_leaf_disease("output.png")

            prediction = (str(disease_dic[prediction]))

            print(prediction)

            
            for plant in plant_data:
                if plant['plant_name'] == prediction:
                    details = plant
                    break


            return render_template('result_page.html', details=details)



           
         #   pass
    return render_template('disease.html', title=title)


# render disease prediction result page


# ===============================================================================================
if __name__ == '__main__':
    app.run(debug=True)
